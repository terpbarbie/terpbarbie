//
//  PlaceDS.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import Foundation
import Combine

class PlaceDS: ObservableObject {
    //singleton design pattern
    static let placeStore = PlaceDS()
    @Published var places: [Place] = []
    
    init() {
        
        places = [

           
            Place(name: "The Vitamin Shoppe", url: "https://www.vitaminshoppe.com/", lat: 39.164110, lng: -76.606870),
            Place(name: "Total Athlete Nutrition", url: "https://www.totalathlete.com", lat: 39.123750, lng: -76.587080),
            Place(name: "GNC", url: "https://www.gnc.com", lat: 39.1581968, lng: -76.7253507),
            Place(name: "Dande-Lion Herb Shop", url: "https://www.dande-lionherbshop.com", lat: 39.1565605, lng: -76.6300316),
            Place(name: "VIDA Activa", url: "https://www.maggieselvin.goherbalife.com", lat: 39.1825819, lng: -76.6147103),
            Place(name: "Healthy 20", url: "https://www.healthy20.net", lat: 39.1389908, lng: -76.60565946),
            Place(name: "5 Star Nutrition", url: "https://www.5starnutritionusa.com", lat: 39.133655, lng: -76.743684),
            
            ]
    }
    // CRUD function
    func addPlace(newPlace: Place) {
        places.append(newPlace)
        //could write to a file, post to internet, insert into Core Data
    }
}
