//
//  Place.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import Foundation

struct Place: Identifiable {
    let id = UUID()
    var name: String
    var url: String
    var lat: Double
    var lng: Double
}
