//
//  ShopsApp.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import SwiftUI

@main
struct ShopsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
