//
//  MapView.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    @ObservedObject var source = PlaceDS.placeStore
    let locationMgr = CLLocationManager()
    
    func makeUIView(context: Context) -> MKMapView {
        return MKMapView()
    }
    func updateUIView( _ uiView: MKMapView, context: Context) {
        
        let center = CLLocationCoordinate2D(latitude: 39.1389907, longitude: -76.6065945)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: center, span: span)
        uiView.setRegion(region, animated: true)
        uiView.addAnnotations(allAnnotations()) //adds items in array to map
        
//blue dot for users current location
        locationMgr.requestWhenInUseAuthorization()
        locationMgr.startUpdatingLocation()
        uiView.showsUserLocation = true
        
    }
    
//make a single pin - aka Anotation
    func oneAnnotation(place: Place) ->
    MKPointAnnotation {
        let annotation = MKPointAnnotation()
        let location = CLLocationCoordinate2D(latitude: place.lat, longitude: place.lng)
        annotation.coordinate = location
        annotation.title = place.name
        return annotation
    }
//make an array of annotations
    func allAnnotations() -> [MKPointAnnotation] {
        var annotations = [MKPointAnnotation]()
        for place in source.places {
            annotations.append(oneAnnotation(place: place))
        }
        return annotations
    }
    
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}

