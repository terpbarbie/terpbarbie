//
//  ListPlace.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import SwiftUI

struct ListPlace: View {
    @ObservedObject var source = PlaceDS.placeStore
    
    var body: some View {
        List(source.places) { place in NavigationLink( destination: WebView(urlString: place.url), label: { Text(place.name)
            })
        }
    }
}

struct ListPlace_Previews: PreviewProvider {
    static var previews: some View {
        ListPlace()
    }
}
