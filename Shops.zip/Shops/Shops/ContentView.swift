//
//  ContentView.swift
//  Shops
//
//  Created by AACC-Student on 5/9/22.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    @State private var showAddView = false    //required for sheet to work
    
    var body: some View {
        NavigationView {
            TabView(selection: $selection,
                    content: {
                ListPlace()
                    .tabItem {
                    VStack {
                        Image(systemName: "list.dash")
                        Text("List")
                    }
                }
                .tag(1)
               MapView()
                    .tabItem {
                        VStack {
                            Image(systemName: "map")
                            Text("Map")
                        }
                                 
                }
                    .tag(2)
        })// selection
            
                .sheet(isPresented: $showAddView, content: {
                    AddPlace()
                }) //sheet
                .navigationTitle("Vitamin Shops")// title at top of screen
                .navigationBarItems(
                    leading:
                        Button (action: {showAddView.toggle()
                        },
                             label: {
                                HStack {
                                    Image(systemName: "plus.circle.fill")
                                        Text("Add New Shop")
                }
                    
                })
                
                )
        }//nav view
            
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

