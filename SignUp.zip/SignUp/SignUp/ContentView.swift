//
//  ContentView.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SignUp()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
