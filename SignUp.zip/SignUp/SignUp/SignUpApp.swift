//
//  SignUpApp.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import SwiftUI

@main
struct SignUpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
