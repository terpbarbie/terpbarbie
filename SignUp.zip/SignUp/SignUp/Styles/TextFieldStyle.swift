//
//  TextFieldStyle.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import SwiftUI

struct TextFieldStyle: ViewModifier {
    var userType: String
    
    func body(content: Content) -> some View {
        content
            .padding(15)
            .background(avatarColors[userType])
            .cornerRadius(50)
            .shadow(color: Color.black, radius: 5, x: 2, y: 2)
    }
}

let avatarColors : [String: Color] =
["Parent" : Color(red: 0.534, green: 0.681, blue: 0.268),
 "Child" : Color(red: 0.99, green: 0.877, blue: 0.636),
 "Teacher" : Color(red: 0.753, green: 0.897, blue: 0.894),
 "Unknown" : Color(red: 255/179, green: 255/179, blue: 255/179)
]
