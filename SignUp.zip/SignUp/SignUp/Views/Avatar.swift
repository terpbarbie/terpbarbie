//
//  Avatar.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import SwiftUI

struct Avatar: View {
    var userType: String
    @Binding var person: Profile
    
    var body: some View {
        Button(action: {
            person.userType = userType
            //print("\(self.person.userType) chosen")
        },
               label: {
        
        VStack {
            Image(userType)
                .resizable()
                .aspectRatio(contentMode: .fit)
            Text(userType)
                .fontWeight(.bold)
                .foregroundColor(avatarColors[userType])
        }
    })
    }
}

struct Avatar_Previews: PreviewProvider {
    static var previews: some View {
        Avatar(userType: "Parent", person: .constant(Profile()))
    }
}
