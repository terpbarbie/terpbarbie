//
//  SignUp.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import SwiftUI

struct SignUp: View {
    @State private var person = Profile()
    @State private var pass2 = ""
    @State private var terms = false
    
    
    var body: some View {
        NavigationView {
            VStack{
                Text ("WHO ARE YOU?")
                HStack {
                    Avatar(userType: "Parent", person: $person)
                    Avatar(userType: "Child", person: $person)
                    Avatar(userType: "Teacher", person: $person)
                }
                .padding(15)
                Form {
                    TextField ("Username", text: $person.username)
                        .modifier(TextFieldStyle(userType: person.userType))
                    TextField ("Email", text: $person.email)
                        .modifier(TextFieldStyle(userType: person.userType))
                    SecureField ("Password", text: $person.password)
                        .modifier(TextFieldStyle(userType: person.userType))
                    SecureField ("Confirm Password", text: $pass2)
                        .modifier(TextFieldStyle(userType: person.userType))
                    
                    Picker(selection: $person.school, label: Text("School"), content: {
                        ForEach(School.allSchools, id: \.self) {
                            school in Text(school)
                            
                        }
                    })
                        .modifier(TextFieldStyle(userType: person.userType))
                    
                    Toggle(isOn: $terms, label: {
                        Text ("Accept Terms and Conditions")
                    
                })
                        .modifier(TextFieldStyle(userType: person.userType))
                    }
                
                    Button (action: {}, label:{
                        Text("SIGN UP")
                    
                })
                    .modifier(TextFieldStyle(userType: person.userType))
                
            }
            .navigationBarTitle("Sign Up",
                                displayMode: .inline)
            
        }
    }
}

struct SignUp_Previews: PreviewProvider {
    static var previews: some View {
        SignUp()
    }
}
