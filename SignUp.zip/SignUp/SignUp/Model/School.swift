//
//  School.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import Foundation

struct School {
    static let allSchools = [
    "Key School",
    "Severn School",
    "Indian Creek School",
    "Annapolis Area Christian School",
    "St Mary's High School",
    "Calvary Baptist Academy",
    "Swade Middle School",
    "Brook Over Water Elementary",
    "Severna Park High School"
    ]
}
