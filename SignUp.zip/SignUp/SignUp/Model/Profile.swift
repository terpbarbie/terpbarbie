//
//  Profile.swift
//  SignUp
//
//  Created by AACC-Student on 4/3/22.
//

import Foundation
import SwiftUI

struct Profile {
    var username: String = ""
    var email: String = ""
    var password: String = ""
    var school: String = ""
    var userType: String = "Unknown"
}


