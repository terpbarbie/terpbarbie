//
//  item.swift
//  ToDo
//
//  Created by AACC-Student on 4/10/22.
//

import Foundation

struct Item: Identifiable, Codable {
    var id = UUID()
    var name: String
    var description: String
    var isChecked: Bool = false
}
