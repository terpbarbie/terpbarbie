//
//  itemDS.swift
//  ToDo
//
//  Created by AACC-Student on 4/10/22.
//

import Foundation

class ItemDS: ObservableObject {
    //Singlton design pattern
    static let ItemsStore = ItemDS()
    
    @Published var items: [Item] = []
    // var objectWillChange = ObservableObjectPublisher()
    // var items: [Item] = [] {
    //  willSet {
    //  //do something special
    //      objectWillChange.send()
    //      }
    //  }
    
    init() {
        print ("Doc directory: \(documentsDirectory())")
        print ("File file: \(dataFilePath())")
        fetchItems()
    }
    
    
    func fetchItems() {
        //preted read data
       // items = [
        //Item(name: "Wash car", description: "Get the car cleaned"),
        //Item(name: "Grade", description: "Grade CTP 250 Labs"),
        //Item(name: "ToDo App", description: "Finish Writing ToDo", isChecked: true),
        //Item(name: "Android Homework", description: "Finish Module 2", isChecked: true),
        
        //]
        let file = dataFilePath()
        if let data = try? Data(contentsOf: file) {
            let decoder = PropertyListDecoder()
            do {
                items = try decoder.decode([Item].self, from: data)
            } catch {
                print("Error decode: \(error.localizedDescription)")
            }
        } else {
            print("=======No File Found")
        }
    }
    func updateItem(whichItem: Item) {
        if let idx = items.firstIndex(where: {$0.id == whichItem.id}) {
            items[idx] = whichItem  //calls setter
        } else {
            items.append(whichItem)
        }
        //saveItems()
    }
    func deleteItem(whichItem: IndexSet) {
        items.remove(atOffsets: whichItem)
    }
    func moveItem (whichItem: IndexSet, destination: Int) {
        items.move(fromOffsets: whichItem, toOffset: destination)
    }
    
    //file I/O
    func documentsDirectory() -> URL {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return path[0]
    }
    func dataFilePath() -> URL {
        return documentsDirectory().appendingPathComponent("ToDo.plist")
    }
    func saveItems() {
        let encode = PropertyListEncoder()
        do {
            let data = try encode.encode(items)
            try data.write(to: dataFilePath(),
                           options: Data.WritingOptions.atomic)
        } catch {
            print ("Error encoding items array: \(error.localizedDescription)")
        }
    }
    
}
