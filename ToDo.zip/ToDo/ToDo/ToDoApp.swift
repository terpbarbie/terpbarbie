//
//  ToDoApp.swift
//  ToDo
//
//  Created by AACC-Student on 4/10/22.
//
//https://peterfriese.dev/ultimte-guide-to-swiftui2-application-lifecycle/#handling-your-applications-life-cycle

import SwiftUI

@main
struct ToDoApp: App {
    @Environment(\.scenePhase) var scenePhase
    @ObservedObject var source = ItemDS.ItemsStore
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .onChange(of: scenePhase) { (newScenePhase) in
            switch newScenePhase {
            case .active:
                print("======APP is active")
            case .inactive:
                print ("===APP is inactive")
            case .background:
                print ("=====APP is in background")
                source.saveItems()
                
            default:                        //default always required
                print("======default...")
            }
        }
    }
}
