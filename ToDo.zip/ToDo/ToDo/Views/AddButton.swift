//
//  AddButton.swift
//  ToDo
//
//  Created by AACC-Student on 4/11/22.
//

import SwiftUI

struct AddButton: View {
    var newItem = Item(name: "", description: "")
    
    var body: some View {
        NavigationLink(
            destination: DetailItem(oneItem: newItem),
            label: {
                HStack {
                    Image(systemName: "plus.circle.fill")
                    Text("Add Item")
                }
            })
        
    }
}

struct AddButton_Previews: PreviewProvider {
    static var previews: some View {
        AddButton()
    }
}
