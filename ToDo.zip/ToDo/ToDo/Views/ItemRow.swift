//
//  ItemRow.swift
//  ToDo
//
//  Created by AACC-Student on 4/10/22.
//

import SwiftUI

struct ItemRow: View {
    var oneItem: Item
    
    var body: some View {
        NavigationLink(
            destination: DetailItem(oneItem: oneItem),
            label: {
                HStack {
                    Text(oneItem.name)
                    Spacer()
                    Text(oneItem.isChecked ? "😺" : "👎🏼") //ctrl-cmd-space = emojis
                    }
                
            })
       
    }
}

struct ItemRow_Previews: PreviewProvider {
    static var previews: some View {
        ItemRow(oneItem: Item(name: "Test", description: "Testing"))
    }
}
