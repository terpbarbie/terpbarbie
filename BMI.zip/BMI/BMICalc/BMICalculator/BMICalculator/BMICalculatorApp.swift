//
//  BMICalculatorApp.swift
//  BMICalculator
//
//  Created by AACC-Student on 3/3/22.
//

import SwiftUI

@main
struct BMICalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
