//
//  ContentView.swift
//  BMICalculator
//
//  Created by AACC-Student on 3/3/22.
//

import SwiftUI

struct ContentView: View {
    @State var ht: Double = 60.0
    @State var wt: Double = 100.0
    @State var bmi: Double = 33.2
    
    
    var body: some View {
        VStack {
            Text("CALCULATE YOUR BMI")
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(80.0)
                .font(.largeTitle)
                .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/, width: 3)
            
            Spacer()
  
            HStack {
                Text ("Height")
                    .padding()
                Spacer()
                Text ("\(ht, specifier: "%.2f") in")
                    .padding()
         }
            Slider(value: $ht, in: 48...84) { _ in calcBMI()
            }
            .padding(.horizontal, 20.0)
            .accentColor(/*@START_MENU_TOKEN@*/Color(red: 0.587, green: 0.944, blue: 0.766)/*@END_MENU_TOKEN@*/)
            
            
            HStack {
                Text ("Weight")
                Spacer()
                Text("\(wt, specifier: "%.2f") lbs")
            }
            .padding()
            
            Slider(value: $wt, in: 90...300) { _ in calcBMI()
            }
            .padding(.horizontal, 20.0)
            .accentColor(Color(red: 0.587, green: 0.944, blue: 0.766))
            
           Spacer()
                Text ("BMI: \(bmi, specifier: "%.2f")")
                .font(.title2)
                .fontWeight(.bold)
                .frame(minWidth: 10, idealWidth: .infinity, maxWidth: .infinity, minHeight: 80, idealHeight: 80, maxHeight: 80, alignment: .center)
                .foregroundColor(Color.blue)
                .multilineTextAlignment(.center)
                .padding(10.0)
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.415, saturation: 0.381, brightness: 0.947)/*@END_MENU_TOKEN@*/)
                .foregroundColor(.blue)


        }
       //primary VStack
        .background(Color.yellow)
        
    } //var body
    
    func calcBMI() {
        bmi = wt * 703 / (ht * ht)
    }
} //content view

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
