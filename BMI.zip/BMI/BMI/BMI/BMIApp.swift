//
//  BMIApp.swift
//  BMI
//
//  Created by AACC-Student on 3/3/22.
//

import SwiftUI

@main
struct BMIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
