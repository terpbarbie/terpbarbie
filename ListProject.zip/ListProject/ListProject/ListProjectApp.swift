//
//  ListProjectApp.swift
//  ListProject
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

@main
struct ListProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
