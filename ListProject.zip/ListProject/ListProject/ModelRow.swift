//
//  ModelRow.swift
//  ListProject
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI


struct ModelRow: View {

    var model: Model

   

    var body: some View {

        HStack {

            Image(model.imageName)

                .resizable()

                .aspectRatio(contentMode: .fit)

                .clipShape(Circle())

                .background(Circle()

                                .foregroundColor(model.country.color))

            Text(model.name)

                .font(.title)

           

        }//Hstack

        .frame(height: 80)

    }

}


struct ModelRow_Previews: PreviewProvider {

    static var previews: some View {

        ModelRow(model: models[4])

            .previewLayout(.fixed(width: 500, height: 100))

    }

}

