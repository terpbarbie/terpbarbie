//
//  ModelList.swift
//  ListProject
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

import SwiftUI


struct ModelList: View {

    var body: some View {

        NavigationView {

            List(models) { currModel in

                NavigationLink(destination: ModelDetail(model: currModel)) {

                    ModelRow(model: currModel)

                }

             

            }

            .navigationBarTitle(Text("Top Models"))

        }

    }

}


struct ModelList_Previews: PreviewProvider {

    static var previews: some View {

       

        ModelList()

    }

}
