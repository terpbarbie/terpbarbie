//
//  Models.swift
//  ListProject
//
//  Created by AACC-Student on 3/13/22.
//

import Foundation
import UIKit
import SwiftUI

struct  Model: Identifiable {

    var id: Int

    var name: String

    var country: country

    var imageName: String

    var age: Int

    var height: String

    var size: Int

}


struct country {

    var color: Color

    var imageName: String

}


let usa = country(color: .white, imageName: "usa")

let china = country(color: .blue, imageName: "china")

let mexico = country(color: .black, imageName: "mexico")


let models = [

    Model(id: 0, name: "Damaris Lewis", country: usa, imageName: "damaris", age: 31, height: "5' 10\"", size: 4),

    Model(id: 1, name: "Liu Wen", country: china, imageName: "liu", age: 34, height: "5' 10\"", size: 2),

    Model(id: 2, name: "Gigi Hadid", country: usa, imageName: "gigi", age: 26, height: "5' 10\"", size: 4),

    Model(id: 3, name: "Cara Delevingne", country: usa, imageName: "cara", age: 29, height: "5' 8\"", size: 4),

    Model(id: 4, name: "Yanet Garcia", country: mexico, imageName: "yanet", age: 31, height: "5' 6\"", size: 6),



]
