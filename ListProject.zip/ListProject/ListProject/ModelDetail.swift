//
//  ModelDetail.swift
//  ListProject
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

struct ModelDetail: View {
    var model: Model

    var body: some View {
        VStack {
        Image(model.country.imageName)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .clipShape(Rectangle())
            
            .background(Rectangle()
                            .foregroundColor(.white))

            Image(model.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(Rectangle())
                
                .background(Rectangle()
                                .foregroundColor(.white))
            
            
        Text(model.name)
            .font(.system(size:40))
            .fontWeight(.heavy)

            ModelStats(label: "Age:", value: "\(model.age)")

            ModelStats(label: "Height:", value: model.height)

            ModelStats(label: "Size:", value: "\(model.size)")

        }//stack

        .edgesIgnoringSafeArea(.top)

    }

}

struct ModelStats: View {

    var label: String

    var value: String

   

    var body: some View {

        HStack {

        Text(label)

                .font(.system(size: 40))

                .fontWeight(.semibold)

                .padding(.leading, 30)

            Text(value)

                .font(.system(size: 40))

                .fontWeight(.regular)

                .foregroundColor(.purple)

            Spacer()

        }

    }

}

struct ModelDetail_Previews: PreviewProvider {

    static var previews: some View {

        ModelDetail(model: models[4])

    }

}


