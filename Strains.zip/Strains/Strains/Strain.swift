//
//  Strain.swift
//  Strains
//
//  Created by AACC-Student EStoko on 2/28/22.
//

import Foundation

class Strain {
    private var _name: String = "Thai G"
    private var _brand: String = "Verano"
    private var _type: String = "Hybrid"
    private var _thc: Double = 29.33
    private var _cbd: Double = 0.0
    
    public var name: String {
        get {return _name}
        set {_name = newValue}
    }
    public var brand: String {
        get {return _brand}
        set {_brand = newValue}
    }
    public var type: String {
        get {return _type}
        set {_type = newValue}
    }
    public var thc: Double {
        get {return _thc}
        set {
            if newValue > 0.0 {
                _thc = newValue
            } else {
                _thc = 0.0
            }
        }
    }
    public var cbd: Double {
        get {return _cbd}
        set {
            if newValue > 0.0 {
                _cbd = newValue
            } else {
                _cbd = 0.0
            }
        }
    }
    //constructors
    
    init(name: String, brand: String, type: String, thc: Double, cbd: Double) {
        _name = name
        _brand = brand
        _type = type
        _thc = thc
        _cbd = cbd
    }
    convenience init (name: String) {
        self.init(name: name, brand: "", type: "", thc: 0.0, cbd: 0.0)
    }
    convenience init () {
        self.init(name: "", brand: "", type: "", thc: 0.0, cbd: 0.0)
    }
    //utility function
    
    func description () -> String {
        return "\nName: \(name)\n"
        + "Brand: \(brand)\n"
        + "Type: \(type)\n"
        + "THC: \(thc)\n"
        + "CBD: \(cbd)\n"
    }
    // class functions
    
    class func testData () -> [Strain] {
        let s1 = Strain(name: "Thai G", brand: "Verano", type: "Hybrid", thc: 29.33, cbd: 0.0)
        let s2 = Strain(name: "Gelato Margy", brand: "Nature's Heritage", type: "Hybrid", thc: 22.35, cbd: 0.34)
        let s3 = Strain(name: "Mag Landrace", brand: "Verano", type: "Indica", thc: 21.47, cbd: 0.0)
        let s4 = Strain(name: "Burmese Mimosa", brand: "Garcia", type: "Sativa", thc: 26.77, cbd: 0.0)
        return [s1, s2, s3, s4]
    }
    
} //end class
