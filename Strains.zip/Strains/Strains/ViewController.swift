//
//  ViewController.swift
//  Strains
//
//  Created by AACC-Student on 2/28/22.
//

import UIKit

class ViewController: UIViewController {
    var allStrains: [Strain] = Strain.testData()
    var currentStrain: Int = 0

    @IBOutlet weak var nameFld: UITextField!
    @IBOutlet weak var brandFld: UITextField!
    @IBOutlet weak var typeFld: UITextField!
    @IBOutlet weak var thcFld: UITextField!
    @IBOutlet weak var cbdFld: UITextField!
    @IBOutlet weak var imageVw: UIImageView!
    
    @IBOutlet weak var prevBtn: UIBarButtonItem!
    @IBOutlet weak var nextBtn: UIBarButtonItem!
    
    
    @IBAction func prevTap(_ sender: Any) {
        currentStrain -= 1
        if currentStrain < 0 {
            currentStrain = 0
        }
        updateUI()
    }
    @IBAction func nextTap(_ sender: Any) {
        currentStrain += 1
        if currentStrain >= allStrains.count {
            currentStrain = allStrains.count - 1
        }
        updateUI()
    }
    @IBAction func saveTap(_ sender: Any) {
        allStrains[currentStrain].name = nameFld.text!
        if let brand = brandFld.text {
            allStrains[currentStrain].brand = brand
        }
        if let type = typeFld.text {
            allStrains[currentStrain].type = type
        }
        if let thc = thcFld.text, let THCP = Double(thc) {
            allStrains[currentStrain].thc = THCP
        }
        if let cbd = cbdFld.text, let CBDP = Double(cbd) {
            allStrains[currentStrain].cbd = CBDP
        }
        updateUI()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateUI()
    }
    
    func updateUI() {
        nameFld.text = allStrains[currentStrain].name
        brandFld.text = allStrains[currentStrain].brand
        typeFld.text = allStrains[currentStrain].type
        thcFld.text = String(allStrains[currentStrain].thc)
        cbdFld.text = String(allStrains[currentStrain].cbd)
        imageVw.image = UIImage(named: allStrains[currentStrain].name)
        
        if currentStrain == 0 {
            prevBtn.isEnabled = false
        } else {
            prevBtn.isEnabled = true
        }
        
        if currentStrain == allStrains.count - 1 {
            nextBtn.isEnabled = false
        } else {
            nextBtn.isEnabled = true
        }
    }

}

