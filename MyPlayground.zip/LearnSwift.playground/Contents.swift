import UIKit

var string = "Hello, playground"
print("Welcome to Swift")
