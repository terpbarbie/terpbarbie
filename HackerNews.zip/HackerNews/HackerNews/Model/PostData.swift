//
//  PostData.swift
//  HackerNews
//
//  Created by AACC-Student on 4/30/22.
//

import Foundation
//info generates an array of posts
struct Post: Identifiable, Decodable {
    var id: String {
        return objectID
    }
    let title: String
    let points: Int
    let url: String?    //optional in case it is not there 
    let objectID: String  //make id = objID
    
    
} //struct

struct Results: Decodable {
    let hits: [Post]
}
