//
//  NetworkMgr.swift
//  HackerNews
//
//  Created by AACC-Student on 4/30/22.
//

import Foundation
//observable obj must be class, published must be observable
class NetworkMgr: ObservableObject {
    @Published var posts: [Post] = []
    
    init() {
        posts = [
            Post(title: "Test", points: 99, url: "https://www.google.com", objectID: "1")
        ]
        fetchData()
    }
    func fetchData() {
        //go to URL to fetch data (APIs)
        guard let url = URL(string: "https://hn.algolia.com/api/v1/search?tags=front_page")
        else {
            print ("Can't create URL")
            return
        }
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: url) {(data, response, err) in
            guard err == nil else {
                print("err has data: \(err.debugDescription)")
                return
            }
            //err is an empty object
            guard let safeData = data else {
                print ("nothing usefu in data")
                return
            }
            //I have data in safeData
            print ("====i have some data")
            print(safeData)
            let decoder = JSONDecoder()
            do {
                let results = try decoder.decode(Results.self, from: safeData)
                print(results.hits[5])
                DispatchQueue.main.async {
                    self.posts = results.hits
                }
                
            } catch {
                print ("cant parse data")
            }
        }
        task.resume() //dont forget
    }
}
