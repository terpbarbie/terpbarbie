//
//  HackerNewsApp.swift
//  HackerNews
//
//  Created by AACC-Student on 4/30/22.
//

import SwiftUI

@main
struct HackerNewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
