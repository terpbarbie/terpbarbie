//
//  List.swift
//  HackerNews
//
//  Created by AACC-Student on 4/30/22.
//

import SwiftUI

struct ListView: View {
    @ObservedObject var net = NetworkMgr()

    var body: some View {
        NavigationView {
            List(net.posts) {
                post in NavigationLink(destination:     WebView(urlString: post.url ?? "https://www.google.com"), label: {
                    HStack {
                        Text("\(post.points)")
                        Text(post.title)
                        
                    }// HStack
                }) //destination
            }
            .navigationTitle("Hacker News")
        }
    }
}

struct List_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
