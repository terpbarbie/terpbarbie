//
//  WebView.swift
//  HackerNews
//
//  Created by AACC-Student on 4/30/22.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let urlString: String
    //2 functions must be written to conform to protocol for webkit
    //1. creates
    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }
    //2. updates
    func updateUIView(_ uiView: UIViewType, context: Context) {
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            uiView.load(request)
        }
    }
}
