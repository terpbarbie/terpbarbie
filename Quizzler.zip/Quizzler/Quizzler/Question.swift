//
//  Question.swift
//  Quizzler
//
//  Created by AACC-Student on 3/7/22.
//

import Foundation

struct Question {
    let text: String
    let options: [String]
    let answer: Int
    
    init(question: String, options: [String], answer: Int) {
        text = question
        self.options = options
        self.answer = answer
    }
    
}
