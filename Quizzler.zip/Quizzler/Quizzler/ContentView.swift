//
//  ContentView.swift
//  Quizzler
//
//  Created by AACC-Student on 3/7/22.
//

import SwiftUI

struct ContentView: View {
    
    var testBank = QuizBank()
    
    @State var text: String = "Welcome"
    @State var choices: [String] = ["Click Next Question to Begin", "", ""]
    @State var choiceIndex: Int = 0
    @State var showAlert: Bool = false
    
    @State var unchecked: Bool = true
    @State var isCorrect: Bool = true
    
    @State var nQuest: Double = 0
    @State var nCorrect: Double = 0
    
    var body: some View {
VStack {
        
        Text(text)
            .font(.largeTitle)
            .foregroundColor(unchecked ? .white : isCorrect ? .green : .red)
    
Picker(selection: $choiceIndex, label: Text("Select one of the following"), content: {
    ForEach (choices.indices, id: \.self) {
                Text(self.choices[$0])
                    .foregroundColor(.white)
            }
        })//picker view
            
    Button(action: check, label: { Text("Check Answer")
                    .foregroundColor(.white)
                    .font(.largeTitle)
                    .frame(minWidth: 20, idealWidth:  .infinity, maxWidth: .infinity, minHeight: 20, idealHeight: 100, maxHeight: 100, alignment: .center)
                
            })//button
                .border(Color.white, width: 3)
                .padding(.bottom)
Button(action: next, label: {
                Text("Next Question")
                    .foregroundColor(.white)
                    .font(.largeTitle)
            })//button
                .frame(minWidth: 20, idealWidth:  .infinity, maxWidth: .infinity, minHeight: 20, idealHeight: 100, maxHeight: 100, alignment: .center)
                .border(Color.white, width: 3)
            
            Spacer()
    }//vstack
.background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.678, saturation: 0.625, brightness: 0.504)/*@END_MENU_TOKEN@*/)
        .onAppear(perform: restart)
        
        .alert(isPresented: $showAlert, content: {
Alert(title: Text("Final Score"),
      message: Text("\(nCorrect/nQuest * 100, specifier: "%.1f")%"),
                  dismissButton: .default(Text("Awesome!!"), action: restart))
        } )
        
    }//body
   func restart() {
        testBank.reset()
        text = testBank.getQuestionText()
        choices = testBank.getOptions()
       nQuest = 1
       nCorrect = 0
       unchecked = true
       
    }
    func next() {
       if testBank.nextQuestion() {
           text = testBank.getQuestionText()
           choices = testBank.getOptions()
           unchecked = true
           nQuest += 1
       } else {
           showAlert = true
       }
        
    }
    func check() {
        isCorrect = testBank.checkAnswer(answer: choiceIndex)
        if unchecked && isCorrect {
            nCorrect += 1
        }
        unchecked = false
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .background()
    }
}
