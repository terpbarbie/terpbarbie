//
//  QuizBank.swift
//  Quizzler
//
//  Created by AACC-Student on 3/7/22.
//

import Foundation

class QuizBank {
    var qNumber: Int = 0
    
    let quiz: [Question] = [
        Question(question: "Mi hermana es baja",
                 options: ["My husband is handsome", "Myfriend is ugly", "My sister is short"],
                 answer: 2),
        Question(question: "Me gusta cerveza fria",
                 options: ["The weather is cold", "I like cold beer", "I like ceviche"],
                 answer: 1),
        Question(question: "El gato es perezoso",
                 options: ["The cat is lazy", "The dog is noisy", "The man is precious"],
                 answer: 0)
    ]
    func getQuestionText() -> String {
        return quiz[qNumber].text
    }
    func getOptions() -> [String] {
        return quiz[qNumber].options
    }
    func nextQuestion() -> Bool {
        var isMore: Bool = false
        if qNumber < quiz.count - 1 {
            qNumber += 1
            isMore = true
        }
        return isMore
    }
    func checkAnswer(answer: Int) -> Bool {
        return (answer == quiz[qNumber].answer)
    }
    func reset() {
        qNumber = 0
    }
    
    
}
