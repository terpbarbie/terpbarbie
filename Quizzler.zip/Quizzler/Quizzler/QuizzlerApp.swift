//
//  QuizzlerApp.swift
//  Quizzler
//
//  Created by AACC-Student on 3/7/22.
//

import SwiftUI

@main
struct QuizzlerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
