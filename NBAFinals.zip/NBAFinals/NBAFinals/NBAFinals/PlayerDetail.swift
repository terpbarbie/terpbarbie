//
//  PlayerDetail.swift
//  NBAFinals
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

struct PlayerDetail: View {
    var player: Player
    
    var body: some View {
        VStack {
        Image(player.team.imageName)
            .resizable()
            .aspectRatio(contentMode: .fit)
            
            Image(player.imageName)
                .clipShape(Circle())
                .background(Circle()
                                .foregroundColor(.white))
                .border(Color.black, width: 5)
                .overlay(Circle()
                            .stroke(Color.white, lineWidth: 5))
                .shadow(radius: 20)
                .offset(x: 0, y: -80)
            
            
        Text(player.name)
            .font(.system(size:50))
            .fontWeight(.heavy)
            
            PlayerStats(label: "Age:", value: "\(player.age)")
            PlayerStats(label: "Height:", value: player.height)
            PlayerStats(label: "Weight:", value: "\(player.weight)")
            
            
        }//stack
        .edgesIgnoringSafeArea(.top)
    }
}
struct PlayerStats: View {
    var label: String
    var value: String
    
    var body: some View {
        HStack {
        Text(label)
                .font(.system(size: 40))
                .fontWeight(.semibold)
                .padding(.leading, 30)
            Text(value)
                .font(.system(size: 40))
                .fontWeight(.regular)
                .foregroundColor(.red)
            Spacer()
        }
    }
}

struct PlayerDetail_Previews: PreviewProvider {
    static var previews: some View {
        PlayerDetail(player: players[3])
    }
}

