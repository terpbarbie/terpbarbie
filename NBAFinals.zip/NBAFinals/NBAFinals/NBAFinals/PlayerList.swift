//
//  PLyerList.swift
//  NBAFinals
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

struct PlayerList: View {
    var body: some View {
        NavigationView {
            List(players) { currPlayer in
                NavigationLink(destination: PlayerDetail(player: currPlayer)) {
                    PlayerRow(player: currPlayer)
                }
              
            }
            .navigationBarTitle(Text("NBA Finals"))
        }
    }
}

struct PlayerList_Previews: PreviewProvider {
    static var previews: some View {
       
        PlayerList()
    }
}


