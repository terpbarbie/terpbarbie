//
//  PlayerRow.swift
//  NBAFinals
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

struct PlayerRow: View {
    var player: Player
    
    var body: some View {
        HStack {
            Image(player.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(Circle())
                .background(Circle()
                                .foregroundColor(player.team.color))
            Text(player.name)
                .font(.title)
            
        }//Hstack
        .frame(height: 80)
    }
}

struct PlayerRow_Previews: PreviewProvider {
    static var previews: some View {
        PlayerRow(player: players[4])
            .previewLayout(.fixed(width: 500, height: 100))
    }
}
