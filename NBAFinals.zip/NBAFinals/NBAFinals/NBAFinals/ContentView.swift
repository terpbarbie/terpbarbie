//
//  ContentView.swift
//  NBAFinals
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PlayerList()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
