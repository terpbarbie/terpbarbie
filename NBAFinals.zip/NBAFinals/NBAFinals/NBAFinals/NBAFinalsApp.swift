//
//  NBAFinalsApp.swift
//  NBAFinals
//
//  Created by AACC-Student on 3/13/22.
//

import SwiftUI

@main
struct NBAFinalsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
