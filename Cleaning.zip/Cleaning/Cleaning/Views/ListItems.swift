//
//  ListItems.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//


import SwiftUI

struct ListItems: View {
    @ObservedObject var source = ItemDS.ItemsStore
    
    var body: some View {
        NavigationView {
            List {
                ForEach(source.items) {item in ItemRow(oneItem: item)
                    
                }
                .onDelete(perform: source.deleteItem)
                .onMove(perform: source.moveItem)
                    
            }
            .navigationTitle("Rooms to Clean")
            .navigationBarItems(leading: AddButton(), trailing: EditButton())
        }   //nav view
    }
}

struct ListItems_Previews: PreviewProvider {
    static var previews: some View {
        ListItems()
    }
}

