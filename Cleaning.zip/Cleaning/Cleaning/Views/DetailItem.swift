//
//  DetailItem.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//

import SwiftUI

struct DetailItem: View {
    @State var oneItem: Item
    @ObservedObject var source = ItemDS.ItemsStore
    @Environment(\.presentationMode) var mode
    
    var body: some View {
        Form {
            Section(header: Text("Room Details")) {
                TextField("Name", text: $oneItem.name)
                TextField("Description", text:$oneItem.description)
                Toggle("Clean", isOn: $oneItem.isChecked)
            }
            Section {
                HStack {
                    Spacer()
                    Button(action: {
                        source.updateItem(whichItem: oneItem)
                        mode.wrappedValue.dismiss()
                    }, label: {
                        Text("Save")
                    })
                    
                Spacer()
                }
            }
        }  //form
    }
}

struct DetailItem_Previews: PreviewProvider {
    static var previews: some View {
        DetailItem(oneItem: Item(name: "Test", description: "Testing"))
    }
}

