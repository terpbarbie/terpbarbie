//
//  AddButton.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//

import SwiftUI

struct AddButton: View {
    var newItem = Item(name: "", description: "")
    
    var body: some View {
        NavigationLink(
            destination: DetailItem(oneItem: newItem),
            label: {
                HStack {
                    Image(systemName: "plus.circle.fill")
                    Text("Add Room")
                }
            })
        
    }
}

struct AddButton_Previews: PreviewProvider {
    static var previews: some View {
        AddButton()
    }
}

