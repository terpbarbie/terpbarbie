//
//  CleaningApp.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//

import SwiftUI

@main
struct CleaningApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
