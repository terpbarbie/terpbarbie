//
//  item.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//

import Foundation

struct Item: Identifiable, Codable {
    var id = UUID()
    var name: String
    var description: String
    var isChecked: Bool = false
}
