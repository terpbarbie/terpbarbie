//
//  ContentView.swift
//  Cleaning
//
//  Created by AACC-Student on 4/17/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       ListItems()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
