//
//  PlaceDS.swift
//  DC Attractions
//
//  Created by Cynthia Woods on 4/20/20.
//  Copyright © 2020 AACC. All rights reserved.
//

import Foundation
import Combine  //??is this needed

class PlaceDS: ObservableObject {
    //singleton design pattern
    static let placeStore = PlaceDS()
    @Published var places: [Place] = []
    
    init() {
        //initialize places array
        places = [

            Place(name: "The White House", url: "https://en.wikipedia.org/wiki/White_House", lat: 38.897885, lng: -77.036551),

            Place(name: "Thomas Jefferson Memorial", url: "https://en.wikipedia.org/wiki/Jefferson_Memorial", lat: 38.881655, lng: -77.036435),

            Place(name: "Einstein Memorial", url: "https://en.wikipedia.org/wiki/Albert_Einstein_Memorial", lat: 38.892647, lng: -77.048452),

            Place(name: "Einstein Memorial - Problem", url: "http://www.nasonline.org/about-nas/visiting-nas/nas-building/the-einstein-memorial.html", lat: 38.892647, lng: -77.048452),

            Place(name: "The US Capitol", url: "https://www.visitthecapitol.gov", lat: 38.889925, lng: -77.009015),

            Place(name: "Lincoln Memorial", url: "https://en.wikipedia.org/wiki/Lincoln_Memorial", lat: 38.889494, lng: -77.050155),

            Place(name: "National Zoo", url: "https://nationalzoo.si.edu", lat: 38.929833, lng: -77.049752),

            Place(name: "National Mall", url: "https://www.nps.gov/nama/index.htm", lat: 38.8896, lng: -77.0230),

            Place(name: "Washington Monument", url: "https://www.nps.gov/wamo/index.htm", lat: 38.889484, lng: -77.035278),

            Place(name: "National Museum of Natural History", url: "https://naturalhistory.si.edu/", lat:38.8913, lng: -77.0261),

            Place(name: "Smithsonian Institution", url: "https://www.si.edu/",  lat: 38.8860, lng: -77.0213),

            Place(name: "United States Holocaust Memorial Museum", url: "https://www.ushmm.org/",  lat: 38.8867, lng: -77.0326)

        ]
    } //init()
    
    // CRUD function
    func addPlace(newPlace: Place) {
        places.append(newPlace)
        //could write to a file, post to internet, insert into Core Data
    }
}
