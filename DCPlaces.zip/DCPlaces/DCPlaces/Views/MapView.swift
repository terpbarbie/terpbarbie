//
//  MapView.swift
//  DCPlaces
//
//  Created by AACC-Student on 5/2/22.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    @ObservedObject var source = PlaceDS.placeStore
    let locationMgr = CLLocationManager()
    
    func makeUIView(context: Context) -> MKMapView {
        return MKMapView()
    }
    func updateUIView( _ uiView: MKMapView, context: Context) {
        
        let center = CLLocationCoordinate2D(latitude: 38.8913, longitude: -77.0261)
        let span = MKCoordinateSpan(latitudeDelta: 0.07, longitudeDelta: 0.07)
        let region = MKCoordinateRegion(center: center, span: span)
        uiView.setRegion(region, animated: true)
        uiView.addAnnotations(allAnnotations()) //adds items in array to map
        
//blue dot for users current location
        locationMgr.requestWhenInUseAuthorization()
        locationMgr.startUpdatingLocation()
        uiView.showsUserLocation = true
        
    }
    
//make a single pin - aka Anotation
    func oneAnnotation(place: Place) ->
    MKPointAnnotation {
        let annotation = MKPointAnnotation()
        let location = CLLocationCoordinate2D(latitude: place.lat, longitude: place.lng)
        annotation.coordinate = location
        annotation.title = place.name
        return annotation
    }
//make an array of annotations
    func allAnnotations() -> [MKPointAnnotation] {
        var annotations = [MKPointAnnotation]()
        for place in source.places {
            annotations.append(oneAnnotation(place: place))
        }
        return annotations
    }
    
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}
