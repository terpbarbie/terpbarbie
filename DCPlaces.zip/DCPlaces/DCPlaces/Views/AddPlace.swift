//
//  AddPlace.swift
//  DCPlaces
//
//  Created by AACC-Student on 5/8/22.
//

import SwiftUI
import CoreLocation     //geo coder

struct AddPlace: View {
    @ObservedObject var source = PlaceDS.placeStore
    @Environment(\.presentationMode) var mode
    
    @State private var name: String = ""
    @State private var address: String = ""
    @State private var url: String = ""
    
    var body: some View {
        Form {
            Section {
                HStack {
                    Spacer()
                    Text("Add New Attraction")
                    Spacer()
                }
            }
            Section {
                TextField("Enter the name", text: $name)
                TextField("123 Main St, Any Town, MD 21012", text: $address)
                TextField("https://www.attraction.com", text: $url)
                
            }
            Section {
                HStack {
                    Spacer()
                    Button(action:createPlace, label: {
                        Text("SAVE")
                    })
                    Spacer()
                }
            }
            
        }
    }
        func createPlace() {
            CLGeocoder().geocodeAddressString(address) {
                (placemarks, err) in
                guard err == nil else {
                    print("Problem with GeoCoder")
                    return
                }
                guard let marks = placemarks,
                      marks.count > 0 else {
                          print("No placemarks created")
                          return
                      }
                guard let lat = marks[0].location?.coordinate.latitude,
                      let lng = marks[0].location?.coordinate.longitude else {
                          print("Cant get lat/long")
                          return
                      }
                //know we have lat/lng
                let place = Place(name: self.name, url: self.url, lat: lat, lng: lng)
                source.addPlace(newPlace: place)
                self.mode.wrappedValue.dismiss()
               
            }
  
        }
}

struct AddPlace_Previews: PreviewProvider {
    static var previews: some View {
        AddPlace()
    }
}
