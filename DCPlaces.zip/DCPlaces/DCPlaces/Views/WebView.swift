//
//  WebView.swift
//  DCPlaces
//
//  Created by AACC-Student on 5/2/22.
//

import WebKit
import SwiftUI

struct WebView: UIViewRepresentable {
    let urlString: String
    
    //make and update UI required to comply with rules
    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if let url = URL(string: urlString) {
           let request = URLRequest(url: url)
            uiView.load(request)
        }
    }
    
}

struct WebView_Previews: PreviewProvider {
    static var previews: some View {
        WebView(urlString: "https://www.aacc.edu")
    }
}
