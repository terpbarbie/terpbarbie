//
//  DCPlacesApp.swift
//  DCPlaces
//
//  Created by AACC-Student on 5/2/22.
//

import SwiftUI

@main
struct DCPlacesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
