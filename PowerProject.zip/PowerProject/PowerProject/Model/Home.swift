//
//  Home.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import Foundation

struct Home: Identifiable {
    let id = UUID()
    var name: String
    var imageName: String
    var lat: Double
    var lng: Double
}
