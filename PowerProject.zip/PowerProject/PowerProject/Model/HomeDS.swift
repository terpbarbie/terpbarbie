//
//  Homes.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import Foundation
import Combine

class HomeDS: ObservableObject {
    
    static let homeStore = HomeDS()
    @Published var homes: [Home] = []
    
    init() {
        
        homes = [

            Home(name: "Amber Brown Roof", imageName: "house1", lat: 39.897885, lng: -77.036551),
            
            Home(name: "Charcoal Roof & Shake Trim", imageName: "house2", lat: 39.13025, lng: -76.553620),
            
            Home(name: "Regatta Blue Siding & Slate Roof", imageName: "house3", lat: 39.13445, lng: -76.5573),
            
            Home(name: "Slate Roof, Country Beige Siding & Lewiston Crest Stone", imageName: "house4", lat: 39.129080, lng: -76.556200),
            
            Home(name: "Bay Window", imageName: "house5", lat: 39.132250, lng: -76.555810),
            
            Home(name: "Double Hung with 1/2 Grid", imageName: "house6", lat: 39.13344, lng: -76.55534)


        ]
    }
    
    func addHome(newHome: Home) {
        homes.append(newHome)
        
    }
}

