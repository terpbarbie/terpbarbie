//
//  PowerProjectApp.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI

@main
struct PowerProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
