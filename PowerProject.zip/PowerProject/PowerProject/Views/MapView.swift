//
//  MapView.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    var home: Home

    func makeUIView(context: Context) -> MKMapView {
        MKMapView()
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        let coordinate = CLLocationCoordinate2D(latitude: home.lat, longitude: home.lng)
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        
        let region = MKCoordinateRegion(center: coordinate, span: span)
        uiView.setRegion(region, animated: true)

        
        uiView.removeAnnotations(uiView.annotations)

        
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = home.name
        uiView.addAnnotation(annotation)

        // Configuration for showing user's location
        uiView.showsUserLocation = true
        let locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
    }
}

