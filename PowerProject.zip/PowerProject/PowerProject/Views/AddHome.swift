//
//  AddHome.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI
import CoreLocation

struct AddHome: View {
    @ObservedObject var source = HomeDS.homeStore
    @Environment(\.presentationMode) var mode
    
    @State private var name: String = ""
    @State private var address: String = ""
    @State private var imageName: String = ""
    
    var body: some View {
        Form {
            Section {
                HStack {
                    Spacer()
                    Text("Add New Homne")
                    Spacer()
                }
            }
            Section {
                TextField("Enter the name", text: $name)
                TextField("123 Main St, Any Town, MD 21012", text: $address)
                TextField("image", text: $imageName)
                
            }
            Section {
                HStack {
                    Spacer()
                    Button(action:createhome, label: {
                        Text("SAVE")
                    })
                    Spacer()
                }
            }
            
        }
    }
        func createhome() {
            CLGeocoder().geocodeAddressString(address) {
                (homemarks, err) in
                guard err == nil else {
                    print("Problem with GeoCoder")
                    return
                }
                guard let marks = homemarks,
                      marks.count > 0 else {
                          print("No homes created")
                          return
                      }
                guard let lat = marks[0].location?.coordinate.latitude,
                      let lng = marks[0].location?.coordinate.longitude else {
                          print("Cant get lat/long")
                          return
                      }
                //know we have lat/lng
                let home = Home(name: self.name, imageName: self.imageName, lat: lat, lng: lng)
                source.addHome(newHome: home)
                self.mode.wrappedValue.dismiss()
               
            }
  
        }
}

struct Addhome_Previews: PreviewProvider {
    static var previews: some View {
        AddHome()
    }
}
