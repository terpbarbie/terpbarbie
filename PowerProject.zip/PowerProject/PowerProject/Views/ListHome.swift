//
//  ListHome.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI

struct ListHome: View {
    @ObservedObject var source = HomeDS() 

    var body: some View {
        List(source.homes) { place in
            NavigationLink(destination: ImageView(imageName: place.imageName), label: {
                Text(place.name)
            })
        }
    }
}
struct ListPlace_Previews: PreviewProvider {
    static var previews: some View {
        ListHome()
    }
}

