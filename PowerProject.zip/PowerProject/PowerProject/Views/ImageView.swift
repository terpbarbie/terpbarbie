//
//  ImageView.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI
import WebKit

struct ImageView: View {
    let imageName: String

    var body: some View {
        Image(imageName)
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
    }



struct WebView_Previews: PreviewProvider {
    static var previews: some View {
        ImageView(imageName: "house1")
    }
}
