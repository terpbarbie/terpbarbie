//
//  ContentView.swift
//  PowerProject
//
//  Created by Elizabeth Stoko on 3/10/24.
//

import SwiftUI

struct ContentView: View {
    // This is using the singleton instance to ensure the data is shared across the views
    @ObservedObject var homeDataStore = HomeDS.homeStore

    var body: some View {
        NavigationView {
            List(homeDataStore.homes) { home in
                NavigationLink(destination: HomeDetailView(home: home)) {
                    Text(home.name)
                }
            }
            .navigationBarTitle("Homes Near You")
        }
    }
}

struct HomeDetailView: View {
    var home: Home
    var body: some View {
        VStack {
            ImageView(imageName: home.imageName) // Display the home image
                .frame(height: 300) // You might want to adjust the height accordingly
            MapView(home: home) // Display the home on the map
                .edgesIgnoringSafeArea(.bottom)
        }
        .navigationBarTitle(Text(home.name), displayMode: .inline)
    }
}
