//
//  ViewController.swift
//  Hello
//
//  Created by AACC-Student on 2/11/22.
//

//IBoutlet
// variable linked to an item on the screen
// IBaction
// is a function that does something

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageVw:
        UIImageView!
    @IBOutlet weak var helloLbl:
        UILabel!
    
    @IBAction func onClick(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

