//
//  ViewController.swift
//  DoggieDaycare
//
//  Created by AACC-Student on 2/27/22.
//

import UIKit

class ViewController: UIViewController {
    var allDogs: [Dog] = Dog.testData()
    var currentDog: Int = 0

    @IBOutlet weak var nameFld: UITextField!
    @IBOutlet weak var breedFld: UITextField!
    @IBOutlet weak var weightFld: UITextField!
    @IBOutlet weak var imageVw: UIImageView!

    @IBOutlet weak var prevBtn: UIBarButtonItem!
    @IBOutlet weak var nextBtn: UIBarButtonItem!
    
    @IBAction func prevTap(_ sender: Any) {
        currentDog -= 1
        if currentDog < 0 {
            currentDog = 0
        }
        updateUI()
    }
    @IBAction func nextTap(_ sender: Any) {
        currentDog += 1
        if currentDog >= allDogs.count {
            currentDog = allDogs.count - 1
        }
       
        updateUI()
    }
    @IBAction func saveTap(_ sender: Any) {
        allDogs[currentDog].name = nameFld.text!
        if let breed = breedFld.text {
            allDogs[currentDog].breed = breed
        }
        if let dogWeight = weightFld.text, let wt = Double(dogWeight){
            allDogs[currentDog].weight = wt
        }
        updateUI()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateUI()
    }
    func updateUI() {
        nameFld.text = allDogs[currentDog].name
        breedFld.text = allDogs[currentDog].breed
        weightFld.text = String(allDogs[currentDog].weight)
        imageVw.image = UIImage(named: allDogs[currentDog].name)
        
        if currentDog == 0 {
            prevBtn.isEnabled = false
        } else {
            prevBtn.isEnabled = true
        }
        if currentDog == allDogs.count - 1 {
            nextBtn.isEnabled = false
        } else {
            nextBtn.isEnabled = true
        }
    }


}

