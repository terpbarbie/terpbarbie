//
//  dog.swift
//  DoggieDaycare
//
//  Created by AACC-Student EStoko on 2/20/22.
//

import Foundation

class Dog {
    private var _name: String = "Fido"
    private var _breed: String = "Poodle"
    private var _weight: Double = 100.0
    
    //setters and getters
    public var name: String {
        get {return _name}
        set {_name = newValue}
    }
    public var breed: String {
        get {return _breed}
        set {_breed = newValue}
    }
    public var weight: Double {
        get {return _weight}
        set {
            if newValue > 0.0 && newValue < 150.0 {
                _weight = newValue
            } else {
                _weight = 0.0
            }
        }
    }
    
    //constructors - initializers
    init(name: String, breed: String, weight: Double) {
        _name = name
        _breed = breed
        _weight = weight
    }
    convenience init (name: String) {
        self.init(name: name, breed: "", weight: 0.0)
    }
    convenience init () {
        self.init(name: "", breed: "", weight: 0.0)
    }
       //utility fnctions
    func description() -> String {
        return "\nName: \(name)\n"
        + "Breed: \(breed)\n"
        + "Weight: \(weight)\n"
    }
    
    //class functions
    //myDog.testData() = use Class name to all these, not object name
    class func testData() -> [Dog] {
        let d1 = Dog(name: "Sparkles", breed: "Poodle", weight: 13.2)
        let d2 = Dog(name: "Fido", breed: "Collie", weight: 78)
        let d3 = Dog(name: "Muffin", breed: "Pittbull", weight: 34.3)
        let d4 = Dog(name: "Rufus", breed: "Shepherd", weight: 44.4)
        return [d1, d2, d3, d4]
    }
    
    
} //end of dog class
