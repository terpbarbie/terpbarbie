//
//  AddBook.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import SwiftUI

struct AddBook: View {
    @ObservedObject var source = BookDS.bookStore
    @Environment(\.presentationMode) var mode
    
    @State private var title = ""
    @State private var author = ""
    @State private var genre = ""
    @State private var rating = 0
    @State private var review = ""
    
    var someBook: book?
    let heading: String
    
    var body: some View {
        NavigationView {
            VStack {
            Form {
                Section {
                    TextField("Name of Book", text: $title)
                    TextField("Author's name", text: $author)
                    Picker("Genre", selection: $genre) {
                        ForEach(book.genres, id:\.self) {
                            Text($0)
                            
                        }
                    }//picker
     Section {
         Rating(rating: $rating)
         TextField("Write a Review", text: $review)
                    }
                }
         Button("Save") {
             if var existingBook = someBook {
                 existingBook.title = title
                 existingBook.author = author
                 existingBook.genre = genre
                 existingBook.rating = rating
                 existingBook.review = review
                 source.addItem(newItem: existingBook)
             } else {
             let newBook = book(
                id: UUID(),
                title: title,
                author: author,
                genre: genre,
                rating: rating,
                review: review)
             source.addItem(newItem: newBook)
             }
             self.mode.wrappedValue.dismiss()
         }
        
    } //form
 .navigationTitle(heading)
        }// navigation view
        .onAppear(perform: {
            if let existingBook = someBook {
                title = existingBook.title
                author = existingBook.author
                genre = existingBook.genre
                rating = existingBook.rating
                review = existingBook.review
            }
        })
    }
}

struct AddBook_Previews: PreviewProvider {
    static var previews: some View {
        AddBook( heading: "Add Book")
    }
}
}
