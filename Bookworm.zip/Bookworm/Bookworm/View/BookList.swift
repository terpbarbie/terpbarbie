//
//  BookList.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import SwiftUI

struct BookList: View {
    @ObservedObject var source = BookDS.bookStore
    @State var showAddScreen = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(source.allBooks, id: \.self) { book in
                    NavigationLink( destination: AddBook(someBook: book, heading: "Edit Book"),
                label: {
                        BookRow(book: book)
            })
                
            }
                .onDelete(perform:source.removeItems)
                .onMove(perform: source.moveItems)
            }
            .navigationBarTitle("BookWorm")
            .navigationBarItems(leading: AddButton(show: $showAddScreen), trailing: EditButton())
            .sheet(isPresented: $showAddScreen, content: {
                AddBook(heading: "Add Book")
            })
        }
    }
}

struct AddButton: View {
    @Binding var show: Bool
    
    var body: some View {
        Button(action: {show.toggle()}, label: {Image(systemName: "plus")
 
        })
    }
}


struct BookList_Previews: PreviewProvider {
    static var previews: some View {
        BookList()
    }
}

