//
//  BookRow.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import SwiftUI

struct BookRow: View {
    let book: book
    
    var body: some View {
        HStack {
            EmojiRating(rating: book.rating)
                .font(.largeTitle)
            VStack(alignment: .leading) {
                Text(book.title)
                Text(book.author)
                    .foregroundColor(.secondary)
            }
        }
    }
}


struct BookRow_Previews: PreviewProvider {
    static var previews: some View {
        BookRow(book: book.example)
    }
}
