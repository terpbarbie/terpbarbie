//
//  BookDetail.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import SwiftUI

struct BookDetail: View {
    let book: book
    
    var body: some View {
        VStack {
            Text(book.title)
                .font(.largeTitle)
            Text(book.author)
                .font(.title)
                .foregroundColor(.secondary)
            Text(book.genre)
                .font(.caption)
            Text(book.review)
        }
    }
}

struct BookDetail_Previews: PreviewProvider {
    static var previews: some View {
        BookDetail(book: book.example)
    }
}
