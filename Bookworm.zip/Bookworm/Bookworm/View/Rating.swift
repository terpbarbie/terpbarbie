//
//  Rating.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import SwiftUI

struct Rating: View {
    @Binding var rating: Int
    
    let max = 5
    let onColor = Color.yellow
    let offColor = Color.gray
    
    var body: some View {
        HStack {
            ForEach (1..<max + 1) { number in
                Image(systemName: "star.fill")
                    .foregroundColor(number > rating ? offColor : onColor)
                    .onTapGesture {
                        rating = number
                    }
            }
        }
    }
}

struct Rating_Previews: PreviewProvider {
    static var previews: some View {
        Rating(rating: .constant(5))
    }
}
