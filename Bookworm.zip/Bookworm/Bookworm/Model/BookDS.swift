//
//  BookDS.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import Foundation
//single design pattern

class BookDS: ObservableObject {
    static let bookStore = BookDS()
    
    @Published var allBooks: [book] = BookDS.fetchData()
    
    func removeItems (at offsets: IndexSet) {
        allBooks.remove(atOffsets: offsets)
    }
    func moveItems (whichItems: IndexSet, destination: Int) {
        allBooks.move(fromOffsets: whichItems, toOffset: destination)
    }
    func addItem (newItem: book) {
        if let idx = allBooks.firstIndex(where: {$0.id == newItem.id}) {
            allBooks[idx] = newItem
        } else {
        allBooks.append(newItem)
        }
    }
    
    class func fetchData() -> [book] {
        return [
            book(id: UUID(), title: "Book 1", author: "HAcking", genre: "Fantasy", rating: 3, review: "None"),
            book(id: UUID(), title: "Book 2", author: "HAcking", genre: "Fantasy", rating: 2, review: "None"),
            book(id: UUID(), title: "Book 3", author: "HAcking", genre: "Fantasy", rating: 1, review: "None"),
            book(id: UUID(), title: "Book 4", author: "HAcking", genre: "Fantasy", rating: 5, review: "None"),
        ]
    }
}
