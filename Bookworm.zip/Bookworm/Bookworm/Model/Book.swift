//
//  Book.swift
//  Bookworm
//
//  Created by AACC-Student on 3/20/22.
//

import Foundation

struct book: Identifiable, Hashable {
    var id: UUID                //apple generates unique IDs
    var title: String
    var author: String
    var genre: String
    var rating: Int
    var review: String
    //dummy for previews
    static let example = book(
                              id: UUID(),
                              title: "A Book",
                              author: "Woods",
                              genre: "Horror",
                              rating: 0,
                              review: "A book for testing purposes")
    
    static let genres = [
        "Fantasy",
        "Horror",
        "Kids",
        "Mystery",
        "Poetry",
        "Romance",
        "Thriller",
        "Text book"
    ]
}
