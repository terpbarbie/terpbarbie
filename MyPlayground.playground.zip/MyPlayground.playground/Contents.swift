import UIKit

var greeting = "Hello, playground"

var myInt = 4
var urInt: Int = 5
let PI: Double = 3.14

//Arrays - Java Array list
var values: [Double] = [123.123, 234.234, 345.345]
print(values[0])

values.append(999.090)
print(values)
print("my array contains \(values.count) items")

var myDbl: Double = values.remove(at: 2)
print(myDbl)

//Dictionary
var airports: [String:String] = [
    "LAX": "LosAngeles",
    "BWI" : "Balt/Wash",
    "DFW" : "Dallas Love Field"
]
    print (airports["DFW"] ?? "Unknown Airport")

//Loops
var numbers: [Int] = []
for i in 1...10 {
    numbers.append(i)
}
print (numbers)
print ("There are \(numbers.count) in my array")

var sum: Int = 0
var i: Int = 0
repeat {
    sum+=numbers[i]
    i += 1
} while i < numbers.count
print ("Sum of all numbers: \(sum)")

sum = 0
i = 0
while i < numbers.count {
    sum+=numbers[i]
    i += 1
}
print ("Sum of all numbers is still: \(sum)")

//if statements
// paranthesis are not required
// braces are always required
if sum < 100 {
    print ("sum is rather small")
}else if sum > 100 {
    print ("sum is rather large")
}else {
    print ("sum is just right")
}

//Functions
func calcBMI(height: Double, weight: Double) -> Double {
    return weight * 703 / (height * height)
}
var bmi = calcBMI(height: 60, weight: 145)
print("BMI: \(bmi)")

var weight: Double = 185.5
var height: Double = 68
bmi = calcBMI(height: height, weight: weight)
print(bmi)

func calcBMI2 (height h: Double, weight w: Double) -> Double {
    return w * 703 / (h * h)
}
bmi = calcBMI2(height: height, weight: weight)
print ("BMI is still \(bmi)")

func calcBMI3 (_ height: Double, _ weight: Double) -> Double {
    return weight * 703 / pow(height, 2)
}
bmi = calcBMI3(72, 100)
print(bmi)

//Optionals
var x: Int = 40
var y: Int?
var z: Int!

var lotteryWinnings: Int?
//print(lotteryWinnings!) //crashes because lotteryW is nil
// lotteryWinnings = 500

if lotteryWinnings != nil {
    print ("Winnings: \(lotteryWinnings!)")
}
if let winnings = lotteryWinnings {
    print (winnings)
} else {
    print ("lotteryWinnings is nil")
}

let winnings = lotteryWinnings ?? 100
print(winnings)

func prtLotto(winnings: Int?) {
    guard let win = winnings else {
        print ("Nil was found!!")
        return
    }
    print ("Winnings are: \(win)")
}

prtLotto(winnings: 5000)
prtLotto(winnings: lotteryWinnings)

/*
 ? = can't guarantee it has a value
 ! = I have code to initialize it before use
 neither = only allowed in classes/structures
    initialize in a constructors
 
 When using vars
 ? = try it, I don't care if it works, ut no crashes
    called optional chaining
 ?? = provide default value if nil
 Use if let or guard to check for nil values
    called optional binding
 */
