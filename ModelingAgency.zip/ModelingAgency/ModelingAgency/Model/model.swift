//
//  model.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import Foundation



struct model: Identifiable, Hashable {

    var id: UUID                //apple generates unique IDs

    var name: String

    var age: String

    var height: String

    var size: String

    var shoe: String

    var hair: String //picker
    
    var resume: String

    var imageName: String

    //dummy for presumes

    static let example = model(

                              id: UUID(),

                              name: "Anna Molly",

                              age: "25",

                              height: "5'11''",

                              size: "2",
 
                              shoe: "7.5",

                              hair: "Blue",
                              
                              resume: "New to urban modeling",
                              
                              imageName: "Erika Caps")
                              
 static let hair = [
        "Auburn",
        "Black",
        "Blonde",
        "Blue",
        "Brown",
"Light Brown",
"Ombre",
"Pink",
"Platinum",
"Purple",
"Red",
"Strawberry Blonde",
"Other",

    ]

}
