//
//  ModelData.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import Foundation


class ModelData: ObservableObject {

    static let agency = ModelData()

   

    @Published var allModels: [model] = ModelData.fetchData()

   

    func removeItems (at offsets: IndexSet) {

        allModels.remove(atOffsets: offsets)

    }

    func moveItems (whichItems: IndexSet, destination: Int) {

        allModels.move(fromOffsets: whichItems, toOffset: destination)

    }

    func addItem (newItem: model) {

        if let idx = allModels.firstIndex(where: {$0.id == newItem.id}) {

            allModels[idx] = newItem

        } else {

        allModels.append(newItem)

        }

    }

   

    class func fetchData() -> [model] {

        return [

            model(id: UUID(), name: "Erika Caps", age: "21", height: "6'0''", size: "2", shoe: "8.5", hair: "Brunette", resume: "Fresh face with runway experience", imageName: "Erika Caps"),
            
            model(id: UUID(), name: "Ana Greskova", age: "29", height: "5'10''", size: "6", shoe: "7.5", hair: "Red", resume: "Seasoned prodessional with 10 years expereince modeling high fashion and avantgard", imageName: "Ana Greskova"),
            
            model(id: UUID(), name: "Lena Marie", age: "17", height: "6'1''", size: "0", shoe: "6.0", hair: "Blonde", resume: "Sports Catalogs", imageName: "Lena Marie"),
            
            model(id: UUID(), name: "Samantha Reed", age: "30", height: "5'8''", size: "4", shoe: "8.0", hair: "Brunette", resume: "Experienced actress and model. Winner of America's next Top Model 2011", imageName: "Samantha Reed"),
            
            model(id: UUID(), name: "Lala Marley", age: "19", height: "5'9''", size: "4", shoe: "7.0", hair: "Pink", resume: "California commercial model mocing into hig fashion", imageName: "Lala Marley"),
            
            model(id: UUID(), name: "Tatianna Bonds", age: "21", height: "5'10''", size: "6", shoe: "7.5", hair: "Black", resume: "None", imageName: "Tatianna Bonds"),

        ]

    }

}
