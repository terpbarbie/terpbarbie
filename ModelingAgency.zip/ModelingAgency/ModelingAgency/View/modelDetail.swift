//
//  modelDetail.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import SwiftUI



struct ModelDetail: View {

    let model: model

   

    var body: some View {

        VStack {

            Text(model.name)

                .font(.largeTitle)
                

            Text(model.age)

                .foregroundColor(.secondary)

            Text(model.height)

                .font(.caption)

            Text(model.size)
                .font(.caption)

            Text(model.shoe)
                .font(.caption)
            
            Text(model.hair)
                .font(.caption)

            Text(model.resume)
                .font(.caption)
                .lineLimit(5)
        }

    }

}



struct ModelDetail_Psizes: PreviewProvider {

    static var previews: some View {

        ModelDetail(model: model.example)

    }

}
