//
//  AddModel.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import SwiftUI



struct AddModel: View {

    @ObservedObject var source = ModelData.agency

    @Environment(\.presentationMode) var mode

   

    @State private var name = ""

    @State private var age = ""

    @State private var height = ""

    @State private var size = ""

@State private var shoe = ""

@State private var hair = ""

    @State private var resume = ""
    
    @State private var imageName = ""

   

    var someModel: model?

    let heading: String

   

    var body: some View {

        NavigationView {

            VStack {

            Form {

                Section {

                    TextField("Name of Model", text: $name)

                    TextField("Age", text: $age)
                    
                    TextField("Height", text: $height)
                    
                    TextField("Dress Size", text: $size)
                    
                 TextField("Shoe Size", text: $shoe)

                    Picker("Hair Color", selection: $hair) {

                        ForEach(model.hair, id:\.self) {

                            Text($0)


                        }

                    }//picker

     Section {

         TextField("Briefly describe your experience", text:$resume)

                    }

                }

         Button("Save") {

             if var existingModel = someModel {

                 existingModel.name = name

                 existingModel.age = age

                 existingModel.height = height

                 existingModel.size = size

                 existingModel.resume = resume

                 source.addItem(newItem: existingModel)

             } else {

             let newModel = model(

                id: UUID(),

                name: name,

                age: age,

                height: height,

                size: size,

                shoe: shoe,

                hair: hair,

                resume: resume,
                
                imageName: imageName)

             source.addItem(newItem: newModel)

             }

             self.mode.wrappedValue.dismiss()

         }

       

    } //form

 .navigationTitle(heading)

        }// navigation view

        .onAppear(perform: {

            if let existingModel = someModel {

                name = existingModel.name

                age = existingModel.age

                height = existingModel.height

                size = existingModel.size

shoe = existingModel.shoe

hair = existingModel.hair

                resume = existingModel.resume


            }

        })

    }

}



struct AddModel_Previews: PreviewProvider {

    static var previews: some View {

        AddModel( heading: "Add Model")

    }

}

}
