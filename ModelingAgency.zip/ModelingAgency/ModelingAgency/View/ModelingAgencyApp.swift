//
//  ModelingAgencyApp.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import SwiftUI

@main
struct ModelingAgencyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
