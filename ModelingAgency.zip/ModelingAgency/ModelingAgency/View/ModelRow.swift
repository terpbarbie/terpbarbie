//
//  ModelRow.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import SwiftUI

struct ModelRow: View {

    let model: model

   

    var body: some View {

        HStack {

            Image(model.imageName)
.resizable()
.aspectRatio(contentMode: .fit)
.frame(width: 152.0, height: 152.0)
.padding(1.0)

            VStack(alignment: .leading) {

                Text(model.name)

                Text(model.age)

                    .foregroundColor(.secondary)

            }

        }

    }

}
