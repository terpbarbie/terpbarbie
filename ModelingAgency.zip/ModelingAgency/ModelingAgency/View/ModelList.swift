//
//  ModelList.swift
//  ModelingAgency
//
//  Created by AACC-Student on 3/21/22.
//

import SwiftUI


struct ModelList: View {

    @ObservedObject var source = ModelData.agency

    @State var showAddScreen = false

   

    var body: some View {

        NavigationView {

            List {

                ForEach(source.allModels, id: \.self) { model in

                    NavigationLink( destination: AddModel(someModel: model, heading: "Edit Model"),

                label: {

                        ModelRow(model: model)

            })

               

            }

                .onDelete(perform:source.removeItems)

                .onMove(perform: source.moveItems)

            }

            .navigationBarTitle("Swift Modeling Agency")

            .navigationBarItems(leading: AddButton(show: $showAddScreen), trailing: EditButton())

            .sheet(isPresented: $showAddScreen, content: {

                AddModel(heading: "Add Model")

            })

        }

    }

}



struct AddButton: View {

    @Binding var show: Bool

   

    var body: some View {

        Button(action: {show.toggle()}, label: {Image(systemName: "plus")

 

        })

    }

}





struct ModelList_Previews: PreviewProvider {

    static var previews: some View {

        ModelList()

    }

}
