//
//  ContentView.swift
//  TipCalculator
//
//  Created by AACC-Student on 3/3/22.
//

import SwiftUI

struct ContentView: View {
    @State var bill: Double = 100.50
    @State var perc: Double = 0.10
    @State var size: Double = 0.0
    @State var tip: Double = 0.0
    @State var split: Double = 0.0
    
    var body: some View {
        VStack {
            Text ("CALCULATE TIP")
                .fontWeight(.semibold)
                .foregroundColor(Color.purple)
                .multilineTextAlignment(.center)
                .padding(80.0)
                .font(.headline)
                .border(/*@START_MENU_TOKEN@*/Color.purple/*@END_MENU_TOKEN@*/, width: 3)
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.black/*@END_MENU_TOKEN@*/)
            
          
  
HStack {
                Text ("Total Bill")
                    .font(.callout)
                    .padding()
                Spacer()
                Text ("\(bill, specifier: "%.2f") $")
                    .padding()
         }
            Slider(value: $bill, in: 1...500) { _ in calcTip()
                calcSplit()
            }
            .padding(.horizontal, 20.0)
            .accentColor(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/)
            
            
 HStack {
                Text ("Tip")
                    .font(.callout)
                Spacer()
                Text("\(perc, specifier: "%.2f") %")
            }
            .padding()
            
            Slider(value: $perc, in: 0.05...0.30) { _ in calcTip()
                calcSplit()
            }
            .padding(.horizontal, 20.0)
            .accentColor(Color.black)

HStack {
               Text ("Party Size")
                    .font(.callout)
                    Text("\(size, specifier: "%.2f") ")
                       }
                       .padding()
                       
            Slider(value: $size, in: 1...12.rounded()) { _ in calcTip()
                           calcSplit()
                       }
                       .padding(.horizontal, 20.0)
                       .accentColor(Color.black)
            
           Spacer()
                Text ("Tip: $\(tip, specifier: "%.2f")")
                .font(.title3)
                .fontWeight(.bold)
                .frame(minWidth: 10, idealWidth: .infinity, maxWidth: .infinity, minHeight: 80, idealHeight: 80, maxHeight: 80, alignment: .center)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.center)
                .padding(10.0)
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.825, saturation: 0.554, brightness: 0.952)/*@END_MENU_TOKEN@*/)
                .foregroundColor(.blue)
            
          
            Text ("Split: $\(split, specifier: "%.2f")")
                .font(.title3)
                 .fontWeight(.bold)
                 .frame(minWidth: 10, idealWidth: .infinity, maxWidth: .infinity, minHeight: 80, idealHeight: 80, maxHeight: 80, alignment: .center)
                 .foregroundColor(Color.black)
                 .multilineTextAlignment(.center)
                 .padding(10.0)
                 .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.926, green: 0.424, blue: 0.953)/*@END_MENU_TOKEN@*/)
                 .foregroundColor(.blue)


        }
        .padding(.horizontal, 20.0)
       //primary VStack
        .background(Color.purple)
        
    } //var body
    
    func calcTip() {
        tip = bill * perc
    }
    func calcSplit() {
        split = (bill + tip) / size
    }
} //content view


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
